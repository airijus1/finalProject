var scroll = new SmoothScroll('.info a[href*="#"]' ,{
	speed: 1000
});

